import json
import boto3

ec2 = boto3.client('ec2')
elbv2 = boto3.client('elbv2')

def lambda_handler(event, context):
    vpc_id = "your-vpc-id"
    target_group_arn = "your-target-group-arn"

    instances = ec2.describe_instances(
        Filters=[
            {'Name': 'tag:ClusterID', 'Values': ['101']},
            {'Name': 'tag:RoleID', 'Values': ['1']}
        ]
    )

    instance_ids = []
    for reservation in instances['Reservations']:
        for instance in reservation['Instances']:
            if instance['State']['Name'] == 'running':
                instance_ids.append(instance['InstanceId'])

    # Register running instances to target group
    if instance_ids:
        elbv2.register_targets(TargetGroupArn=target_group_arn, Targets=[{'Id': id} for id in instance_ids])

    # Remove terminated instances
    target_health = elbv2.describe_target_health(TargetGroupArn=target_group_arn)
    registered_instances = {target['Target']['Id'] for target in target_health['TargetHealthDescriptions']}
    for instance_id in registered_instances - set(instance_ids):
        elbv2.deregister_targets(TargetGroupArn=target_group_arn, Targets=[{'Id': instance_id}])

    return {
        'statusCode': 200,
        'body': json.dumps('Lambda executed successfully!')
    }

